package com.niit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.UserDAO;
import com.niit.model.Collab_User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserDAO userdao;
	
	@Transactional
	public void setUserDao(UserDAO userdao)
	{
		this.userdao=userdao;
	}

	@Transactional
	public void saveOrUpdate(Collab_User user) {
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public Collab_User getUserById(int userid) {
		
		return userdao.getUserById(userid);
	}

	@Transactional
	public List<Collab_User> list() {
		
		return userdao.list();
	}

	@Transactional
	public Collab_User getUserByname(String username) {
		
		return userdao.getUserByname(username);
	}

}

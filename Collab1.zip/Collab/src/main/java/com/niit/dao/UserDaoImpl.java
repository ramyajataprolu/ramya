package com.niit.dao;


import com.niit.model.*;
import java.util.*;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.niit.model.Collab_User;
@Repository
@Transactional
public class UserDaoImpl implements UserDAO {
	
	public UserDaoImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	


	public void saveOrUpdate(Collab_User user)
	{
	Session s =sessionFactory.getCurrentSession();
	Transaction t = s.beginTransaction();
	s.saveOrUpdate(user);
	t.commit();
		
		
	}

	@Override
	public Collab_User getUserById(int userid) {
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		Collab_User u=(Collab_User) session.load(Collab_User.class,userid);
		System.out.println("data of user by id="+u);
		tx.commit();
		return u;	
	}

	@Override
	public List<Collab_User> list() {
		
		@SuppressWarnings("unchecked")
		Session session=this.sessionFactory.getCurrentSession();
		 @SuppressWarnings("unchecked")
		List<Collab_User> user = (List<Collab_User>) sessionFactory.getCurrentSession().createCriteria(Collab_User.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		 return user;
	}

	@SuppressWarnings("unchecked")
	public Collab_User getUserByname(String username) {
		System.out.println("getting data in dao based on name"+username);
		Session session=this.sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		Criteria cr=session.createCriteria(Collab_User.class);
		cr.add(Restrictions.eq("username", username));
		List<Collab_User> users = cr.list();
		Collab_User user = users.get(0);
		System.out.println("User Data="+user.getUsername());
		tx.commit();
		return user;
	}
	

}

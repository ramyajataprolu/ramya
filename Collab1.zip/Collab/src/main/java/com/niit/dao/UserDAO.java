package com.niit.dao;

import java.util.List;

import com.niit.model.*;

public interface UserDAO {
	public void saveOrUpdate(Collab_User user);
	public Collab_User getUserById(int userid);
	public  List<Collab_User> list();
	public Collab_User getUserByname(String username);
	

}

package com.niit.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.Collab_User;
import com.niit.service.UserService;

@Controller
public class HomeController 
{
	@Autowired
	UserService uservice;

@RequestMapping("/")
public ModelAndView Home()
{
	System.out.println("in home conroller");
	return new ModelAndView("index");
}
@RequestMapping("/reg")
public ModelAndView RegPage()
{
	System.out.println("for registration conroller");
	return new ModelAndView("signup");
}
	
@RequestMapping("/register")
public String createUser(@ModelAttribute("collab_user") Collab_User user , Model model,HttpServletRequest request, MultipartFile file) throws IOException
{
	
	//String filename = null;
    //byte[] bytes;
    
    		user.setRole("ROLE_USER");
    		user.setIsenabled(true);
            uservice.saveOrUpdate(user);
    		System.out.println("Data Inserted");
            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
    		MultipartFile image = user.getPicture();
            //Path path;
           // String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserid()+".jpg");
    		//D:\CollabXml\.metadata\.plugins\org.eclipse.wst.server.core\tmp0\wtpwebapps\Collab\resources\images\
    		String path = request.getSession().getServletContext().getRealPath("D:\\CollabXml\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\Collab\\resources\\images\\"+user.getUserid()+".jpg");
            System.out.println("Path="+path);
            System.out.println(request.getSession().getServletContext());
            System.out.println("File name = " + user.getPicture().getOriginalFilename());
          
            if(image!=null && !image.isEmpty())
            {
            	try
            	{
            		image.transferTo(new File(path.toString()));
            		System.out.println("Image saved  in:"+path.toString());
            	}
            	catch(Exception e)
            	{
            		e.printStackTrace();
            		System.out.println("Image not saved");
            	}
            }
    	
     	    
    return "home";
}
@ModelAttribute("collab_user")
public  Collab_User returnObject()
{
	return new Collab_User();
}


}

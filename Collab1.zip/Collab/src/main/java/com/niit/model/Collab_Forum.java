package com.niit.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Collab_Forum")
public class Collab_Forum {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(unique=true)
	private String forum_id;
	@NotEmpty(message="title shouldnt be empty")
	private String forum_title;
	@NotEmpty(message="content shouldnt be empty")
	private String forum_content;
	
	private Date forum_creation;
	@NotEmpty(message="category shouldnt be empty")
	private String category;
	@NotEmpty(message="username of forum shouldnt be empty")
	private String f_username;
	public String getForum_id() {
		return forum_id;
	}
	public void setForum_id(String forum_id) {
		this.forum_id = forum_id;
	}
	public String getForum_title() {
		return forum_title;
	}
	public void setForum_title(String forum_title) {
		this.forum_title = forum_title;
	}
	public String getForum_content() {
		return forum_content;
	}
	public void setForum_content(String forum_content) {
		this.forum_content = forum_content;
	}
	public Date getForum_creation() {
		return forum_creation;
	}
	public void setForum_creation(Date forum_creation) {
		this.forum_creation = forum_creation;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getF_username() {
		return f_username;
	}
	public void setF_username(String f_username) {
		this.f_username = f_username;
	}

}

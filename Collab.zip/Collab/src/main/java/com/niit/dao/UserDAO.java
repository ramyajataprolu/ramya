package com.niit.dao;

public class UserDAO {

}

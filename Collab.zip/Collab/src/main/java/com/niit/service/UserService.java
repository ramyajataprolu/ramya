package com.niit.service;
import com.niit.model.*;
import java.util.*;
public class UserService {

	public void setUserDao(UserDAO userdao);
	public void saveOrUpdate(Collab_User user) ;
	public Collab_User getUserById(int userid) ;
	public List<Collab_User> list();
	public Collab_User getUserByname(String username);
}

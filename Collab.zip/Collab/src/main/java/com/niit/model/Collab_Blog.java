package com.niit.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Collab_Blog")
public class Collab_Blog {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(unique=true)
	private int blog_id;
    @NotEmpty(message="title of the blog should not be empty")
	private String blog_title;
    @NotEmpty(message="Contents of the blog should not be left empty")
	private String blog_content;
  
	private Date blog_creation;
	@NotEmpty(message="username should not be left empty")
	private String b_username;
	public int getBlog_id() {
		return blog_id;
	}
	public void setBlog_id(int blog_id) {
		this.blog_id = blog_id;
	}
	public String getBlog_title() {
		return blog_title;
	}
	public void setBlog_title(String blog_title) {
		this.blog_title = blog_title;
	}
	public String getBlog_content() {
		return blog_content;
	}
	public void setBlog_content(String blog_content) {
		this.blog_content = blog_content;
	}
	public Date getBlog_creation() {
		return blog_creation;
	}
	public void setBlog_creation(Date blog_creation) {
		this.blog_creation = blog_creation;
	}
	public String getUsername() {
		return b_username;
	}
	public void setUsername(String b_username) {
		this.b_username = b_username;
	}
	
	
}
